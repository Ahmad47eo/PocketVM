export function validateMemory(memoryMb) {
  if (![128, 256, 512].includes(Number(memoryMb))) {
    throw new Error("Choose one of the supported memory presets: 128, 256, or 512 MB.");
  }
  return Number(memoryMb);
}

export async function getRuntimeStatus(checkPath) {
  const paths = [
    "/vendor/v86/libv86.js",
    "/vendor/v86/v86.wasm",
    "/vendor/v86/seabios.bin",
    "/vendor/v86/vgabios.bin"
  ];
  const checks = await Promise.all(paths.map((path) => checkPath(path)));
  return { ready: checks.every(Boolean), missing: paths.filter((_, i) => !checks[i]) };
}

export function formatError(error) {
  if (error instanceof Error && error.message) return error.message;
  return "An unknown error occurred. Check the browser console for details.";
}
