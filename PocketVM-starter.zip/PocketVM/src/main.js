import "./style.css";
import { getRuntimeStatus, validateMemory, formatError } from "./vm.js";

const $ = (id) => document.getElementById(id);
const startButton = $("start");
const stopButton = $("stop");
const resetButton = $("reset");
const status = $("status");
const message = $("message");
const screen = $("screen");
const runtimeBadge = $("runtime-badge");
let emulator = null;
let selectedIso = null;

$("iso").addEventListener("change", (event) => {
  selectedIso = event.target.files?.[0] ?? null;
  message.textContent = selectedIso
    ? `Selected ${selectedIso.name} (${Math.round(selectedIso.size / 1024 / 1024)} MB). The emulator runtime is still required.`
    : "No ISO selected.";
});

async function loadRuntime() {
  // The user must supply a verified, locally hosted v86 build. Never silently
  // load executable runtime code from an unverified third-party URL.
  if (typeof window.V86Starter === "function") return window.V86Starter;
  const script = document.createElement("script");
  script.src = "/vendor/v86/libv86.js";
  script.async = true;
  await new Promise((resolve, reject) => {
    script.onload = resolve;
    script.onerror = () => reject(new Error("Missing /vendor/v86/libv86.js. Follow README.md to add the verified v86 runtime."));
    document.head.appendChild(script);
  });
  if (typeof window.V86Starter !== "function") {
    throw new Error("The v86 script loaded but did not expose V86Starter. Check that the runtime files match the documented v86 build.");
  }
  return window.V86Starter;
}

function setRunning(running) {
  startButton.disabled = running;
  stopButton.disabled = !running;
  resetButton.disabled = !running;
}

function showError(error) {
  const detail = formatError(error);
  status.textContent = "Error";
  message.textContent = detail;
  screen.innerHTML = `<div class="empty-state"><strong>VM could not start</strong><p></p></div>`;
  screen.querySelector("p").textContent = detail;
  setRunning(false);
}

startButton.addEventListener("click", async () => {
  if (emulator) return;
  const memoryMb = Number($("memory").value);
  try {
    validateMemory(memoryMb);
    if (!selectedIso) throw new Error("Choose a compatible Linux ISO first.");
    message.textContent = "Checking local emulator runtime…";
    status.textContent = "Loading";
    const V86Starter = await loadRuntime();
    const wasmPath = "/vendor/v86/v86.wasm";
    const biosPath = "/vendor/v86/seabios.bin";
    const vgaBiosPath = "/vendor/v86/vgabios.bin";
    const wasmResponse = await fetch(wasmPath, { method: "HEAD" });
    const biosResponse = await fetch(biosPath, { method: "HEAD" });
    const vgaResponse = await fetch(vgaBiosPath, { method: "HEAD" });
    if (!wasmResponse.ok || !biosResponse.ok || !vgaResponse.ok) {
      throw new Error("One or more v86 runtime assets are missing. Check /vendor/v86/ and follow README.md.");
    }
    screen.replaceChildren();
    const display = document.createElement("div");
    display.id = "vm-display";
    screen.appendChild(display);
    const isoUrl = URL.createObjectURL(selectedIso);
    message.textContent = "Starting emulator. Boot success has not been verified yet…";
    emulator = new V86Starter({
      wasm_path: wasmPath,
      memory_size: memoryMb * 1024 * 1024,
      vga_memory_size: 8 * 1024 * 1024,
      bios: { url: biosPath },
      vga_bios: { url: vgaBiosPath },
      cdrom: { url: isoUrl },
      screen_container: display,
      autostart: true
    });
    emulator.add_listener("emulator-ready", () => {
      status.textContent = "Running";
      message.textContent = "Emulator initialized. This does not by itself prove that Linux finished booting.";
      setRunning(true);
    });
    emulator.add_listener("emulator-started", () => {
      status.textContent = "Booting";
      message.textContent = "Emulator started; waiting for Linux boot output.";
    });
    setRunning(true);
    window.addEventListener("pagehide", () => {
      try { emulator?.stop(); } catch { /* best effort during page shutdown */ }
      URL.revokeObjectURL(isoUrl);
    }, { once: true });
  } catch (error) {
    if (emulator) {
      try { emulator.stop(); } catch { /* ignore cleanup error */ }
      emulator = null;
    }
    showError(error);
  }
});

stopButton.addEventListener("click", () => {
  if (!emulator) return;
  try {
    emulator.stop();
    emulator = null;
    status.textContent = "Stopped";
    message.textContent = "VM stopped. Disk/state persistence is not implemented in this starter scaffold.";
    screen.innerHTML = '<div class="empty-state"><strong>VM stopped</strong><p>Start again to boot a new session.</p></div>';
    setRunning(false);
  } catch (error) {
    showError(error);
  }
});

resetButton.addEventListener("click", () => {
  if (!emulator) return;
  try {
    emulator.stop();
    emulator = null;
    status.textContent = "Reset";
    message.textContent = "VM reset. Press Start VM to create a fresh session.";
    screen.innerHTML = '<div class="empty-state"><strong>VM reset</strong><p>No fake boot output is shown.</p></div>';
    setRunning(false);
  } catch (error) {
    showError(error);
  }
});

(async () => {
  const result = await getRuntimeStatus(async (path) => {
    try { return (await fetch(path, { method: "HEAD" })).ok; } catch { return false; }
  });
  runtimeBadge.textContent = result.ready ? "Runtime detected" : "Runtime not installed";
  if (result.ready) message.textContent = "Runtime files detected. Choose a compatible Linux ISO and press Start VM.";
})();
