import test from "node:test";
import assert from "node:assert/strict";
import { validateMemory, getRuntimeStatus, formatError } from "../src/vm.js";

test("accepts supported memory presets", () => {
  assert.equal(validateMemory(128), 128);
  assert.equal(validateMemory(256), 256);
  assert.equal(validateMemory(512), 512);
});

test("rejects unsupported memory presets", () => {
  assert.throws(() => validateMemory(1024), /supported memory presets/);
  assert.throws(() => validateMemory("abc"), /supported memory presets/);
});

test("reports all missing runtime files", async () => {
  const result = await getRuntimeStatus(async (path) => path.endsWith("libv86.js"));
  assert.equal(result.ready, false);
  assert.equal(result.missing.length, 3);
  assert.ok(result.missing.includes("/vendor/v86/v86.wasm"));
});

test("reports runtime ready only when every asset exists", async () => {
  const result = await getRuntimeStatus(async () => true);
  assert.equal(result.ready, true);
  assert.deepEqual(result.missing, []);
});

test("formats errors without hiding their message", () => {
  assert.equal(formatError(new Error("asset missing")), "asset missing");
  assert.match(formatError("unexpected"), /unknown error/i);
});
