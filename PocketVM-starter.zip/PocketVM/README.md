# PocketVM (starter scaffold)

PocketVM is a mobile-first web interface for a browser-local x86 VM. This scaffold is **not yet a verified working VM**: emulator runtime files and a compatible Linux ISO are intentionally not bundled, and an actual Linux boot has not been tested.

## Requirements

- Node.js 20 or newer
- Internet access on the computer used to install dependencies and obtain the emulator files
- A compatible v86 browser build and its matching WebAssembly, BIOS, and VGA BIOS assets
- A legally redistributable x86 Linux ISO (or an ISO you are entitled to use)

## Run the interface

```sh
npm install
npm test
npm run dev
```

Open the local Vite URL on your computer. To test from an iPhone on the same Wi-Fi, open the network URL printed by Vite. The development server must be reachable from the phone.

## Add the emulator runtime

This scaffold deliberately does not download executable runtime code from an unverified URL. Obtain a compatible build from the official v86 project:

- Project: https://github.com/copy/v86
- Upstream demo/documentation: https://copy.sh/v86/

Review the current upstream build instructions and license. Use files from the same build/version and place the compatible files here:

```text
public/
  vendor/
    v86/
      libv86.js
      v86.wasm
      seabios.bin
      vgabios.bin
```

The expected file names are the paths used by this scaffold; upstream builds may name or package files differently, so verify them before copying. Do not rename unrelated files to make checks pass. The app expects the browser global `V86Starter` and the documented `bios`, `vga_bios`, `wasm_path`, `cdrom`, and `screen_container` options; adjust the adapter if the upstream version changes.

Then restart the development server. Select a compatible ISO in the page and press **Start VM**.

## Important limitations

- A successful `emulator-ready` event means the emulator initialized; it does **not** prove Linux completed booting.
- This initial scaffold does not implement persistent virtual disks, save/restore snapshots, serial console input, a touch keyboard, or a verified asset-fetch script.
- The ISO is loaded from the file selected by the user, so it is not uploaded by this app.
- iOS may suspend tabs or terminate them under memory pressure. Large images and high memory settings may fail.
- Do not publish third-party BIOS, emulator, or OS image files unless their licenses permit redistribution.
- This starter project has not been tested on a physical iPhone.

## Build and test

```sh
npm test
npm run build
npm run preview
```

Deploy the generated `dist/` directory to a static hosting provider such as Cloudflare Pages or Netlify. Add the runtime files only if you have the right to distribute them, and remember that static hosting limits and file-size limits apply.

## Security note

The app loads the emulator script from a local `/vendor/v86/` path rather than injecting remote executable code at runtime. Always review third-party runtime licenses and versions before publishing.
